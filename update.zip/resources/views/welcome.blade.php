<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peaks Hotel | KCA University</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="icon" href="{{ asset('favicon.svg') }}" type="image/svg+xml">
    <style>
        html { scroll-behavior: smooth; }
        body { font-family: 'Figtree', sans-serif; background-color: #f8f9fa; }
        .hero-section { background-color: #192C57; color: white; padding: 160px 0; position: relative; overflow: hidden; display: flex; align-items: center; }
        .btn-explore { background-color: white; color: #192C57; font-weight: 800; padding: 15px 40px; border-radius: 50px; border: 2px solid white; transition: 0.4s ease; text-transform: uppercase; letter-spacing: 1px; position: relative; z-index: 10; }
        .btn-explore:hover { background-color: #CEAA0C; border-color: #CEAA0C; color: #192C57; transform: translateY(-3px); box-shadow: 0 10px 20px rgba(206, 170, 12, 0.4); }
        #flipping-text { color: #CEAA0C; font-weight: 800; display: inline-block; min-width: 180px; transition: opacity 0.5s ease; }
        .food-card { transition: transform 0.3s ease, box-shadow 0.3s ease; border: none; border-radius: 15px; overflow: hidden; }
        .food-card:hover { transform: translateY(-10px); box-shadow: 0 15px 30px rgba(0,0,0,0.1); }
        .floating-icons { position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 0; }
        .floating-icons i { position: absolute; color: rgba(255, 255, 255, 0.1); font-size: 2.5rem; animation: floatAround 12s linear infinite; opacity: 0; }
        .icon-1 { top: 15%; left: 10%; animation-delay: 0s; } .icon-2 { top: 60%; left: 20%; animation-delay: 2s; } .icon-3 { top: 25%; left: 80%; animation-delay: 4s; } .icon-4 { top: 75%; left: 70%; animation-delay: 6s; } .icon-5 { top: 45%; left: 45%; animation-delay: 1s; }
        @keyframes floatAround { 0% { transform: translateY(100vh) rotate(0deg); opacity: 0; } 20% { opacity: 0.6; } 80% { opacity: 0.6; } 100% { transform: translateY(-100px) rotate(360deg); opacity: 0; } }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top py-3">
    <div class="container">
        <a class="navbar-brand fw-bold" href="{{ route('home') }}" style="color: #192C57; font-size: 1.5rem;">
            <i class="fas fa-graduation-cap" style="color: #CEAA0C;"></i> KCA<span style="color: #CEAA0C;">U</span>
        </a>
        
        <button class="navbar-toggler border-0 shadow-none position-relative me-2 mt-1" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
            <span class="navbar-toggler-icon"></span>
            @php $cartCount = count(session('cart', [])); @endphp
            @if($cartCount > 0)
                <span id="hamburger-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger border border-white shadow-sm" style="font-size: 0.65rem;">
                    {{ $cartCount }}
                </span>
            @endif
        </button>
        
        <div class="collapse navbar-collapse justify-content-end" id="navbarContent">
            <div class="d-flex flex-column flex-lg-row align-items-lg-center gap-3 mt-3 mt-lg-0">
                <a href="{{ route('menu.all') }}" class="text-decoration-none fw-bold text-lg-start" style="color: #192C57;">MENU</a>
                
                <a href="{{ route('cart.index') }}" id="nav-cart-btn" class="btn btn-light position-relative rounded-pill px-3 border shadow-sm align-self-start align-self-lg-auto">
                    <i class="fas fa-shopping-cart" style="color: #192C57;"></i>
                    @php $cartCount = count(session('cart', [])); @endphp
                    @if($cartCount > 0)
                    <span id="cart-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{{ $cartCount }}</span>
                    @endif
                </a>

                @if(Auth::check())
                    @if(Auth::user()->hasRole('admin'))
                        <a href="{{ route('admin.dashboard') }}" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-bold align-self-start align-self-lg-auto">DASHBOARD</a>
                    @else
                        <a href="{{ route('orders.index') }}" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-bold align-self-start align-self-lg-auto">MY PORTAL</a>
                    @endif

                    <div class="d-flex align-items-center bg-light px-3 py-2 rounded-pill border shadow-sm align-self-start align-self-lg-auto">
                        <i class="fas fa-user-circle text-primary me-2"></i>
                        <span class="fw-bold text-dark" style="font-size: 0.85rem;">
                            {{ Auth::user()->name }} 
                            @if(Auth::user()->staff_number)
                                <span class="badge bg-secondary ms-1">{{ Auth::user()->staff_number }}</span>
                            @endif
                        </span>
                    </div>
                    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="btn btn-outline-danger rounded-pill px-4 fw-bold align-self-start align-self-lg-auto">LOGOUT</a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">@csrf</form>
                @else
                    <a href="{{ route('login') }}" class="btn btn-primary rounded-pill px-4 fw-bold shadow-sm align-self-start align-self-lg-auto" style="background-color: #192C57;">LOGIN</a>
                @endif
            </div>
        </div>
    </div>
</nav>

<div class="hero-section text-center">
    <div class="floating-icons">
        <i class="fas fa-hamburger icon-1"></i><i class="fas fa-pizza-slice icon-2"></i><i class="fas fa-ice-cream icon-3"></i><i class="fas fa-coffee icon-4"></i><i class="fas fa-utensils icon-5"></i>
    </div>
    <div class="container" style="position: relative; z-index: 1;">
        <h1 class="display-2 fw-bold mb-3">Peaks Hotel Cafeteria</h1>
        <p class="h3 mb-5 fw-light">Quality, Affordable Meals for <span id="flipping-text">Everyone</span></p>
        <a href="#menu-start" class="btn btn-explore shadow-lg btn-lg">View Today's Menu <i class="fas fa-arrow-down ms-2"></i></a>
    </div>
</div>

<section class="py-5 bg-white">
    <div class="container py-4">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <i class="fas fa-university fa-4x mb-3" style="color: #192C57;"></i>
                <h2 class="fw-bold mb-3" style="color: #192C57;">Excellence in Every Meal</h2>
                <div style="width: 60px; height: 4px; background: #CEAA0C; margin-bottom: 20px;"></div>
                <p class="text-muted lead">The Peaks Hotel Cafeteria is dedicated to serving the students, staff, and visitors of KCA University. We believe that a good meal fuels the mind for academic excellence.</p>
                <p class="text-muted"><strong>Note to Staff:</strong> You can login via the Staff Portal to access your daily meal allowances. Students and visitors can order directly using M-Pesa without logging in.</p>
            </div>
            <div class="col-lg-6">
                <div class="row g-3">
                    <div class="col-6"><div class="p-4 rounded-4 text-center shadow-sm bg-light"><i class="fas fa-leaf fa-2x mb-3 text-success"></i><h6 class="fw-bold">Fresh Ingredients</h6></div></div>
                    <div class="col-6"><div class="p-4 rounded-4 text-center shadow-sm bg-light"><i class="fas fa-wallet fa-2x mb-3 text-primary"></i><h6 class="fw-bold">Affordable Prices</h6></div></div>
                    <div class="col-6"><div class="p-4 rounded-4 text-center shadow-sm bg-light"><i class="fas fa-mobile-alt fa-2x mb-3 text-warning"></i><h6 class="fw-bold">M-Pesa Integration</h6></div></div>
                    <div class="col-6"><div class="p-4 rounded-4 text-center shadow-sm bg-light"><i class="fas fa-users fa-2x mb-3 text-danger"></i><h6 class="fw-bold">Community Focused</h6></div></div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container my-5" id="menu-start">
    <div class="d-flex justify-content-between align-items-end mb-4">
        <div><h2 class="fw-bold" style="color: #192C57;">Today's Top Picks</h2><div style="width: 50px; height: 3px; background: #CEAA0C;"></div></div>
        <a href="{{ route('menu.all') }}" class="btn btn-outline-dark rounded-pill px-4">View Full Menu <i class="fas fa-arrow-right ms-2"></i></a>
    </div>

    <div class="row g-4">
    @forelse($featuredItems as $item)
        <div class="col-lg-3 col-md-4 col-6">
            <div class="card h-100 border-0 shadow-sm food-card" onclick="addToCart({{ $item->id }})" style="cursor: pointer;">
                <div style="height: 150px; background: #f8f9fa; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                    @if($item->image)
                        <img src="{{ asset($item->image) }}" alt="{{ $item->name }}" style="width: 100%; height: 100%; object-fit: cover;">
                    @else
                        <i class="fas fa-hamburger fa-3x text-muted opacity-50"></i>
                    @endif
                </div>
                <div class="card-body position-relative d-flex flex-column">
                    <span id="counter-{{ $item->id }}" class="badge bg-warning text-dark position-absolute top-0 start-50 translate-middle-x shadow-sm" style="display:none; transition: opacity 0.5s ease; z-index: 10; border-radius: 50px; padding: 5px 15px;"></span>
                    <h6 class="fw-bold mb-1">{{ $item->name }}</h6>
                    <p class="text-muted small mb-3">{{ Str::limit($item->description, 35) }}</p>
                    <div class="mt-auto d-flex justify-content-between align-items-center">
                        <span class="fw-bold" style="color: #192C57;">KES {{ number_format($item->price, 0) }}</span>
                        
                        <button type="button" class="btn btn-sm btn-dark rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width: 35px; height: 35px; pointer-events: none;">
    <i class="fas fa-plus text-white"></i>
</button>
                    </div>
                </div>
            </div>
        </div>
    @empty
        <div class="col-12 text-center py-5">
            <p class="text-muted">No featured items available right now.</p>
        </div>
    @endforelse
    </div>

    <div class="text-center mt-5">
        <a href="{{ route('menu.all') }}" class="btn btn-primary px-5 py-3 rounded-pill fw-bold shadow" style="background-color: #192C57;">
            EXPLORE ALL CATEGORIES
        </a>
    </div>
</div>

<div id="toast-box" style="display:none; position: fixed; bottom: 30px; right: 30px; z-index: 9999; background: #192C57; color: #CEAA0C; padding: 15px 25px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); animation: slideIn 0.3s;">
    <i class="fas fa-check-circle me-2"></i> Added to Cart!
</div>

<script>
    const phrases = ["Everyone", "Staff", "Students", "Visitors", "Parents"];
    let i = 0; const el = document.getElementById('flipping-text');
    if (el) { setInterval(() => { el.style.opacity = 0; setTimeout(() => { i = (i + 1) % phrases.length; el.innerText = phrases[i]; el.style.opacity = 1; }, 500); }, 2500); }

    let fadeTimers = {};
    function addToCart(id) {
        fetch('/add-to-cart/' + id, { headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content') }})
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const toast = document.getElementById('toast-box');
                if (toast) { 
                    if (data.exceeds_allowance) {
                        toast.style.background = '#dc3545'; 
                        toast.style.color = '#fff';
                        toast.innerHTML = '<i class="fas fa-exclamation-triangle me-2"></i> Exceeds Wallet! Excess will be via M-Pesa.';
                    } else {
                        toast.style.background = '#192C57'; 
                        toast.style.color = '#CEAA0C'; 
                        toast.innerHTML = '<i class="fas fa-check-circle me-2"></i> Added to Cart!';
                    }
                    
                    toast.style.display = 'block'; 
                    setTimeout(() => { toast.style.display = 'none'; }, 3500); 
                }

                // --- 1. UPDATE THE MAIN CART BADGE ---
                const badge = document.getElementById('cart-badge');
                if (badge) { 
                    badge.innerText = data.cart_count; 
                } else { 
                    const cartBtn = document.getElementById('nav-cart-btn'); 
                    if (cartBtn) { 
                        cartBtn.insertAdjacentHTML('beforeend', `<span id="cart-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">${data.cart_count}</span>`); 
                    } 
                }
                
                // --- 2. UPDATE THE NEW HAMBURGER MENU BADGE ---
                const burgerBadge = document.getElementById('hamburger-badge');
                if (burgerBadge) {
                    burgerBadge.innerText = data.cart_count;
                } else {
                    const burgerBtn = document.querySelector('.navbar-toggler');
                    if (burgerBtn) {
                        burgerBtn.insertAdjacentHTML('beforeend', `<span id="hamburger-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger border border-white shadow-sm" style="font-size: 0.65rem;">${data.cart_count}</span>`);
                    }
                }
                // ----------------------------------------------
                
                const itemCounter = document.getElementById('counter-' + id);
                if (itemCounter) {
                    if (fadeTimers[id]) clearTimeout(fadeTimers[id]);
                    itemCounter.innerText = 'x' + data.item_quantity; itemCounter.style.display = 'block';
                    setTimeout(() => { itemCounter.style.opacity = '1'; }, 10);
                    fadeTimers[id] = setTimeout(() => { itemCounter.style.opacity = '0'; setTimeout(() => { itemCounter.style.display = 'none'; }, 500); }, 1500);
                }
            }
        });
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
@include('layouts.footer')
</body>
</html>